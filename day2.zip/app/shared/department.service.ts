import { Injectable } from '@angular/core';


@Injectable()
export class Department {

    loadDept():string[]{
        return ['IT','Finance','Hospitality']
    }
}