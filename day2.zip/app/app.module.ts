import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainApp } from './mainapp.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { UserData } from './shared/userdata.service';
import { Department } from './shared/department.service';
import { FormsModule} from "@angular/forms";

@NgModule({
  declarations: [
    AppComponent,
    MainApp,
    HeaderComponent,
    FooterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [UserData,Department],
  bootstrap: [AppComponent]
})
export class AppModule { }
