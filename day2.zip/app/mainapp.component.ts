import { Component } from '@angular/core';
import { UserData } from './shared/userdata.service';
import { Department } from './shared/department.service';



@Component({
    selector: 'main-app',
    templateUrl: 'mainapp.component.html'
})
export class MainApp {

    constructor( private ud:UserData,private dep:Department){
this.userdata= this.ud.loadUsers()
this.department=this.dep.loadDept()
    }

    welcomemsg=' welcome to my component'
   department
    userdata

}